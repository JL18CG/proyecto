

<?php $__env->startSection('link_a','active'); ?>
<?php $__env->startSection('link_a_a','activo-l'); ?>
<?php $__env->startSection('link_directorios','active'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 mb-5">
        <h3 class="my-4 text-center">Directorio</h3>
        <hr class="divider-sm">
        <?php if(!$presidente->isEmpty()): ?>
        <div class="col-12">
            <div class="card bg-light mx-auto mb-5 mt-5 card-directorios" >
                <img class="card-img-top" src="<?php echo e(asset('web/img/directorio/'.$presidente[0]->img)); ?>" alt="Card image cap">
                <div class="card-header card-header-directorio text-center card-pres"><?php echo e($presidente[0]->cargo); ?></div>
                <div class="card-body">
                  <h5 class="card-title text-center dir-nombre"><?php echo e($presidente[0]->nombre_completo); ?></h5>
                  
                </div>
            </div>
        </div>
        <hr class="divider-sm">
        <?php endif; ?>
    </div>
   
</div>

<div class="row mb-5">
    <?php $__currentLoopData = $directorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $directorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card bg-light mx-auto mb-5 mt-5 card-directorios">
        <img class="card-img-top" src="<?php echo e(asset('web/img/directorio/'.$directorio->img)); ?>" alt="Card image cap">
        <div class="card-header card-header-directorio text-center card-pres "><?php echo e($directorio->cargo); ?></div>
        <div class="card-body card-body-directorio">
          <h5 class="card-title text-center dir-nombre"><?php echo e($directorio->nombre_completo); ?></h5>
          
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
    

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.main-sec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/directorio/index.blade.php ENDPATH**/ ?>