
<?php $__env->startSection('titulo'); ?> Turismo <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="pb-5">

    <a href="<?php echo e(route("turismo.inicio")); ?>" type="button" class="btn btn-danger mt-5"><i class="fa fa-arrow-left"></i> Regresar  </a>
            
    <form  class="mt-3 mb-5 pb-2" action="<?php echo e(route("sitios.update",$sitio->id)); ?>" method="POST" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('panel.turismo._forml', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="submit" value="Guardar Datos" class="btn btn-success mt-3 float-right">
    </form>

</div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
<script>

    window.onload = function (){

        $('#btn-img-s').click(function(){
            $("#img-s").click();
        });
            
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader(); 
                reader.onload = function(e) {
                    $('#prev-sitio').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
    
        $("#img-s").change(function() {
            readURL(this);
        });
    }
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/turismo/edit_l.blade.php ENDPATH**/ ?>