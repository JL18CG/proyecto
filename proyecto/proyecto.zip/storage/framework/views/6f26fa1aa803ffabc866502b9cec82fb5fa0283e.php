
<?php $__env->startSection('titulo'); ?> Usuarios <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="pb-5">

    <a href="<?php echo e(route("usuarios.index")); ?>" type="button" class="btn btn-danger mt-5"><i class="fa fa-arrow-left"></i> Regresar  </a>
            
    <form  class="mt-3 mb-5 pb-2" action="<?php echo e(route("usuarios.update",$usuario->id)); ?>" method="POST" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('panel.user._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="submit" value="Guardar Datos" class="btn btn-success mt-3 float-right">
    </form>



</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        var input=  document.getElementById('tel-contacto');
        input.addEventListener('input',function(){
        if (this.value.length > 10) 
        this.value = this.value.slice(0,10); 
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/user/edit.blade.php ENDPATH**/ ?>