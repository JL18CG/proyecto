


<?php $__env->startSection('link_a_a','activo-l'); ?>

<?php $__env->startSection('link', 'btn-outline-info'); ?>
<?php $__env->startSection('link_m', 'btn-outline-info'); ?>
<?php $__env->startSection('link_t', 'btn-outline-info'); ?>
<?php $__env->startSection('link_a', 'btn-outline-info'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <h3 class="my-4">Tesorería</h3>
        <hr class="divider-sm">
    </div>

    <div class="col-xs-12 col-sm-6  col-md-6 col-lg-3 text-center">
        <a type="button" href="<?php echo e(route('sevac.index')); ?>" class="btn <?php echo $__env->yieldContent('link'); ?> p-3 d-block mt-2">SEVAC</a>
    </div>
    <div class="col-xs-12 col-sm-6  col-md-6 col-lg-3 text-center">
        <a type="button" href="<?php echo e(route('mensual.index')); ?>" class="btn <?php echo $__env->yieldContent('link_m'); ?> p-3 d-block mt-2">Reportes Mensuales</a>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 text-center">
        <a type="button" href="<?php echo e(route('trimestral.index')); ?>" class="btn <?php echo $__env->yieldContent('link_t'); ?> p-3 d-block mt-2">Reportes Trimestrales</a>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 text-center">
        <a type="button" href="<?php echo e(route('anual.index')); ?>" class="btn <?php echo $__env->yieldContent('link_a'); ?> p-3 d-block mt-2">Reportes Anuales</a>
    </div>

    <?php echo $__env->yieldContent('contenedor'); ?>
    
    <div class="col-12 mt-1 mb-1 text-center">
        <p class="d-block">Busca <i class="fa fa-search text-info"></i> y descarga los archivos en formato PDF <i class="fa fa-file-pdf text-info"></i></p>    
    </div>

 
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.main-sec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/tesoreria/index.blade.php ENDPATH**/ ?>