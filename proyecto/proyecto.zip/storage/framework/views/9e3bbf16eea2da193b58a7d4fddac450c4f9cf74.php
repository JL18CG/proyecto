
<?php $__env->startSection('titulo'); ?> Usuarios <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>  Usuarios  </h1>
<a class="btn btn-success mt-3 mb-3" href="<?php echo e(route('user.create')); ?>"> +Crear</a>

<table class="table">
    <thead>
        <td> ID </td>
        <td> Nombre </td>
        <td> Nivel </td>
        <td> Acciones </td>
        <td> Acciones </td>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($user->id); ?>

            </td>
            <td>
                <?php echo e($user->name); ?>

            </td>
            <td>
                <?php echo e($user->level); ?>

            </td>
            <td>
                <?php echo e($user->created_at->format('d-m-y')); ?>

            </td>
            <td>
                <?php echo e($user->updated_at->format('d-m-y')); ?>

            </td>
            <td>
                <a href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-primary"> ver </a>
                <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-secondary"> actualizar </a>

                <form method="POST" action="<?php echo e(route('user.destroy', $user->id)); ?>">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn" type="submit">Eliminar</button>               
                </form>                  
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/Panel/user/index.blade.php ENDPATH**/ ?>