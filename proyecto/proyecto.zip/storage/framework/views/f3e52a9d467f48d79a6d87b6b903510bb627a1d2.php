

<?php $__env->startSection('link_n','active'); ?>
<?php $__env->startSection('link_n_a','activo-l'); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
    <!-- Post Content Column -->
    <div class="col-12">
      <!-- Title -->
     <h3 class="mt-4 text-justify pl-2 pr-2 text-noticia-show"><?php echo e($noticia[0]->titulo); ?></h3>
     <hr class="divider-sm">
      <!-- Preview Image -->
      <img class="img-fluid rounded mx-auto d-block" src="<?php echo e(asset('web/img/noticias/'.$noticia[0]->imagen)); ?>" alt="">
      <!-- Author -->
      <p class="lead-autor d-block mt-3  pr-2 text-right">Noticia publicada por <?php echo e($noticia[0]->autor); ?></p>
      <hr class="show-n">
      <p class="text-justify">  <?php echo $noticia[0]->descripcion; ?> </p>
      <hr class="show-n">
      <p class="d-block"><small class="float-right"> <i class="fa fa-clock"></i> Publicado <?php echo e($date->diffForHumans()); ?> </small> <br> </p>

    </div>

</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.main-sec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/noticias/show.blade.php ENDPATH**/ ?>