
<?php $__env->startSection('titulo'); ?> Directorios <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="pb-5">
    <a href="<?php echo e(route("directorios.index")); ?>" type="button" class="btn btn-danger mt-5"><i class="fa fa-arrow-left"></i> Regresar  </a>
    
    <form  class="mt-3 mb-5 pb-2" action="<?php echo e(route("directorios.store")); ?>" method="POST" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('panel.directorios._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <input type="submit" value="Guardar Datos" class="btn btn-success mt-3 float-right">
    </form>
    
</div>




<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
    <script>
        $('#btn-directorio').click(function(){
            $("#dir-img").click();
        });

        function getURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader(); 
                reader.onload = function(e) {
                    $('#prev-img').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#dir-img").change(function() {
            getURL(this);           
           
        });



        var input=  document.getElementById('telefono-a');
        input.addEventListener('input',function(){
        if (this.value.length > 10) 
        this.value = this.value.slice(0,10); 
        })


        var input=  document.getElementById('telefono-ext');
        input.addEventListener('input',function(){
        if (this.value.length > 3) 
        this.value = this.value.slice(0,3); 
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/directorios/create.blade.php ENDPATH**/ ?>