
<?php $__env->startSection('titulo'); ?> Noticias <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-5">

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <a href="<?php echo e(route("noticias.index")); ?>" type="button" class="btn btn-danger mt-5"><i class="fa fa-arrow-left"></i> Regresar  </a>
            
    <form  class="mt-3 pb-5" action="<?php echo e(route("noticias.update",$noticia->id)); ?>" method="POST" enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('panel.noticias._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <input type="submit" value="Actualizar Datos" class="btn btn-success mt-3 float-right">
    </form>
    
</div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset("web/editor/ckeditor.js")); ?>"></script>
<script>
    window.onload = function (){
        CKEDITOR.replace('contenido');	
    
        $('#btn-img').click(function(){
        $("#img").click();
    });
        
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader(); 
            reader.onload = function(e) {
                $('#blah').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

    $("#img").change(function() {
        readURL(this);
    });
    
    
    
    
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/noticias/edit.blade.php ENDPATH**/ ?>