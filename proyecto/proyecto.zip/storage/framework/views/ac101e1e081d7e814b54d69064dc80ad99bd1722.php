
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route("user.update",$users->id)); ?>" method="POST">
    <?php echo method_field('PUT'); ?>
    
    <?php echo $__env->make('Panel.user._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input type="submit" value="enviar" class="btn btn-primary">




</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/Panel/user/edit.blade.php ENDPATH**/ ?>