<div class="row">
    <div class="form-group col-sm-12 col-md-4">
            <label for="tipo-rep">Selecciona el Tipo de Reporte*</label>
            <select class="form-control" id="tipo-rep" name="reporte">
                <option <?php echo e($reporte->tipo == "general" ? 'selected' :''); ?> value="general" >Reporte General</option>
                <option <?php echo e($reporte->tipo == "sevac" ? 'selected' :''); ?>  value="sevac">Reporte SEVAC</option>
            </select>
    </div>

    <div class="form-group col-sm-12 col-md-4">
            <label for="tipo-rep">Selecciona la Categoría del Reporte*</label>
            <select class="form-control" id="cat-rep" name="clasificacion">
                <option <?php echo e($reporte->clas_reporte == "mensual" ? 'selected' :''); ?>  value="mensual" >Reporte Mensual</option>
                <option <?php echo e($reporte->clas_reporte == "trimestral" ? 'selected' :''); ?>  value="trimestral">Reporte Trimestral</option>
                <option <?php echo e($reporte->clas_reporte == "anual" ? 'selected' :''); ?>  value="anual" >Reporte Anual</option>
            </select>
    </div>

    <div class="form-group col-sm-12 col-md-4">
        <label for="n-archivo">Agrega el Nombre del Documento*</label>
        <input class="form-control pl-3 pr-3 mr-5  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="nombre" maxlength="70" id="n-archivo" value="<?php echo e(old('nombre',$reporte->titulo)); ?>">
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">El nombre es obligatorio.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <small  class="ml-3 form-text text-muted">Ejemplo: "Reporte Trimestral Agosto-Noviembre 2020"</small>
    </div>

    <div class="form-group col-12 ">
        
    <hr>
        <label for="img">Cargar Archivo PDF*</label>
        <button type="button" class="ml-3 btn btn-info " id="btn-pdf"><i class="fa fa-upload mr-1"></i> Seleccionar Archivo</button>
        <input class="form-control  <?php $__errorArgs = ['pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> d-none" type="file" accept="application/pdf" name="pdf" id="pdf">
        <?php $__errorArgs = ['pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">Formato PDF y peso menor de 5mb obligatorio.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         <div  class="col-12 mt-2 pdf-v-p <?php echo e($reporte->archivo ? : 'd-none'); ?>">
            <iframe  id="pdf-view" src ="<?php echo e($reporte->archivo ? asset('storage/reportes/'.$reporte->archivo) : ''); ?>" class="col-12" height="500px"></iframe>
        </div>
    </div>
</div>


<?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/reportes/_form.blade.php ENDPATH**/ ?>