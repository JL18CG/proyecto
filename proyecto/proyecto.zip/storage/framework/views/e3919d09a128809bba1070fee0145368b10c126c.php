
<div class="modal fade mt-5 d-none"  id="deleteModalNoticia" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog mt-5 "  role="document">
    <div class="modal-content  mt-5" >
        <div class="modal-header " >
            <h5 class="modal-title" id="modalLabel"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <p>¿Seguro que desea borrar el registro seleccionado?</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

            <form id="formDelete" method="POST" action="<?php echo e(route('noticias.destroy',0)); ?>"
                data-action="<?php echo e(route('noticias.destroy',0)); ?>">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Borrar</button>
            </form>


        </div>
    </div>
</div>
</div><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/partials/_modals.blade.php ENDPATH**/ ?>