<div class="row">
    <div class="form-group col-4">
            <label for="nombre_lugar">Nombre*</label>
            <input class="form-control pl-3 pr-3 mr-5  <?php $__errorArgs = ['nombre_lugar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="nombre_lugar" id="nombre_lugar" value="<?php echo e(old('nombre_lugar',$sitio->nombre_lugar)); ?>">
            <?php $__errorArgs = ['nombre_lugar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">Introduce un Nombre Válido.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-8">
            <label for="tipo_lugar">Tipo de Lugar*</label>
            <select class="form-control  <?php $__errorArgs = ['tipo_lugar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipo_lugar" id="tipo_lugar" value="<?php echo e(old('tipo_lugar',$sitio->tipo_lugar)); ?>">
                <option value="v1">Valor 1</option>
                <option value="v2">Valor 2</option>
                <option value="v3">Valor 3</option>
                <option value="v4">Valor 4</option>
              </select>
            <?php $__errorArgs = ['tipo_lugar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">Selecciona un Tipo de Lugar Válido.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <hr>
    <div class="form-group col-8">
        <label for="ubicacion">Ubicacion</label>
        <input type="text"  class="form-control is-invalid" hidden>
        <input class="form-control  <?php $__errorArgs = ['ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="ubicacion" id="ubicacion" value="<?php echo e(old('ubicacion', $sitio->ubicacion)); ?> "> 
        <?php $__errorArgs = ['ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback mt-2">Introduce una Ubicación Válida.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <hr>
<div class="form-group col-4">
<label for="fecha">Direccion*</label>
<input class="form-control  <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="direccion" id="direccion" value="<?php echo e(old('direccion',$sitio->direccion)); ?>">
<?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">Introduce un Lugar Válido.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-12">
<label for="descripcion">Descripcion*</label>
<textarea class="form-control  <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="descripcion" id="descripcion"> <?php echo e(old('descripcion',$sitio->descripcion)); ?> </textarea>
<?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">Introduce un Descipción Válida.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>


<hr>

<div class="form-group col-12 m-table">
    <label for="img">Cargar Imagen*</label>
    <button type="button" class="ml-3 btn btn-info " id="btn-img-s"><i class="fa fa-upload mr-1"></i> Seleccionar Archivo</button>
    <input class="form-control  <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> d-none" type="file" accept="image/*" name="imagen" id="img-s">
    <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <div class="invalid-feedback">La Imagen debe ser formato JPG, JPEG o PNG y pesar menos de 1MB.</div>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div  class="col-12 mt-2">
        <img id="prev-sitio"  class="mx-auto d-block img-fluid" src="<?php echo e($sitio->img ? asset('web/img/sitios/'.$sitio->img) : ''); ?>" alt="" />
    </div>
</div><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/turismo/_forml.blade.php ENDPATH**/ ?>