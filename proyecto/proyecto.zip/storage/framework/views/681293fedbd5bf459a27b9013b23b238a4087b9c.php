<?php $__env->startSection('link_n_mu','activo-l'); ?>



<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">  
<h3 style="margin-top:1rem;">Sitios Interesantes para Visitar</h3>
</div>
<?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  
<div class="row">  
    <div class="card col-12" style="width: 18rem; margin-bottom:1rem; margin-top:1rem;">
        <img class="d-block w-100" src="<?php echo e(asset("web/img/evts/thumbs/".$evento->img)); ?>" alt="">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($evento->titulo); ?></h5>
          <p class="card-text"><?php echo e($evento->desc); ?></p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">Fecha: <?php echo e(date('d-m-Y', strtotime($evento->fecha))); ?></li>
          <li class="list-group-item">Hora: <?php echo e(date('G:i', strtotime($evento->tiempo))); ?></li> 
          <p class="col-6"> Lugar: <?php echo e($evento->lugar); ?></p>
        </ul>
      </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> 
<?php echo e($eventos->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.main-sec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/eventos/index.blade.php ENDPATH**/ ?>