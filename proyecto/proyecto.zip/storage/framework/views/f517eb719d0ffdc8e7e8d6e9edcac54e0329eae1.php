<?php if(Auth::user()->roles()->pluck('token')->contains('Noticia')): ?>

    <li class="nav-item">
        <a href="<?php echo e(route("noticias.index")); ?>"  data-toggle="tooltip" title="Noticias" class="nav-link pl-3 pr-3 <?php echo e($link_noticia ?? ''); ?>"> <i class="mr-1 fa fa-newspaper"></i>Noticias</a>
    </li>

<?php endif; ?>

<?php if(Auth::user()->roles()->pluck('token')->contains('Directorio')): ?>
    <li class="nav-item">
        <a href="<?php echo e(route("directorios.index")); ?>" data-toggle="tooltip" title="Directorios" class="nav-link pl-3 pr-3 <?php echo e($link_directorio ?? ''); ?>"> <i class="mr-1 fa fa-address-book"></i>Directorios</a>
    </li>
<?php endif; ?>

<?php if(Auth::user()->roles()->pluck('token')->contains('Turismo')): ?>
    <li class="nav-item">
        <a href="<?php echo e(route("turismo.inicio")); ?>" data-toggle="tooltip" title="Turismo" class="nav-link pl-3 pr-3 <?php echo e($link_turismo ?? ''); ?>"> <i class="mr-1 fa fa-bus"></i>Turismo</a>
    </li>
<?php endif; ?>

<?php if(Auth::user()->roles()->pluck('token')->contains('Reporte')): ?>
    <li class="nav-item">
        <a href="<?php echo e(route("reportes.index")); ?>" data-toggle="tooltip" title="Reportes" class="nav-link pl-3 pr-3 <?php echo e($link_reportes ?? ''); ?>"> <i class="mr-1 fa fa-file-pdf"></i>Reportes</a>
    </li>
<?php endif; ?>

<?php if(Auth::user()->roles()->pluck('token')->contains('Consulta')): ?>
    <li class="nav-item">
        <a href="<?php echo e(route("consultas.index")); ?>" data-toggle="tooltip" title="Consultas" class="nav-link pl-3 pr-3"> <i class="mr-1 fa fa-envelope"></i>Consultas</a>
    </li>
<?php endif; ?>


<li class="nav-item">
    <a href="<?php echo e(route('logout')); ?>" id="log-out" data-toggle="tooltip" title="Cerrar Sesión" class=" nav-link pl-3 pr-3 rounded btn btn-outline-danger"><?php echo e(Str::upper(auth()->user()->name)); ?> <i class="mr-1 fa fa-sign-out-alt"></i>  </a>
</li><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/partials/nav_user.blade.php ENDPATH**/ ?>