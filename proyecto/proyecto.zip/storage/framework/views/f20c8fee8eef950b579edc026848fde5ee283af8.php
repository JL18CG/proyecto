
<?php $__env->startSection('titulo'); ?> Usuarios <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pt-1 pb-5">
    <h3 class="h2 d-block pt-2">Panel de Usuarios</h3>
    <hr>
    <p>Agrega a usuarios para que ayuden a administrar el contenido de la página.</p>


    <ul class="nav nav-tabs mt-4" id="myTab" role="tablist">
        <li class="nav-item ">
        <a class="nav-link <?php echo e((session('active-rol')) ? '' : 'active'); ?> " id="home-tab" data-toggle="tab" href="#p-usuarios" role="tab" aria-controls="p-noticia" aria-selected="true">Usuarios y Auditorías</a>
        </li>
        <li class="nav-item ">
        <a class="nav-link <?php echo e((session('active-rol')) ? 'active' : '  '); ?> " id="profile-tab" data-toggle="tab" href="#p-roles" role="tab" aria-controls="profile" aria-selected="false">Registro de Roles</a>
        </li>
    </ul>

   
    <div class="tab-content" id="myTabContent">

        <div class="tab-pane fade <?php echo e((session('active-rol')) ? '' : 'active show'); ?>" id="p-usuarios" role="tabpanel" aria-labelledby="home-tab">
            <div class="mt-3">
                <h3>Registro de Usuarios</h3>
                <a href="<?php echo e(route("usuarios.create")); ?>" type="button" class="btn btn-success mt-2 mb-2 col-12-xs">Agregar <i class="fa fa-plus"></i> </a>
                <form action="<?php echo e(route('usuarios.index')); ?>" class="form-inline float-right mt-2">
                    <select name="created_at" class="form-control mr-3">
                            <option value="DESC">Descenente</option>
                            <option  <?php echo e(request('created_at') == "ASC" ? "selected": ""); ?> value="ASC">Ascendente</option>
                    </select>
                    <input type="text" value="<?php echo e(request('busqueda')); ?>" name="busqueda" placeholder="Buscar" class="form-control mr-3">

                    <button type="submit" class="btn btn-success"><i class="fa fa-search"></i></button>
                </form>
                    <div class=" table-responsive ">
                        <table class="table table-hover">
                            <caption>Lista de Usuarios Registrados</caption>
                            <thead>
                            <tr class="fondo">
                                <th scope="col" style="width: 250px">Nombre</th>
                                <th scope="col " style="width: 400px" class="text-justify">Nivel</th>
                                <th scope="col"  style="width: 250px" class="text-center">Correo Electrónico</th>
                                <th scope="col">Teléfono</th>
                                <th scope="col"><div class="text-center tabla-w"><span>Acciones</span></div></th>
                            </tr>
                            </thead>
                            <tbody>
                
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                    
                                <?php if(auth()->user()->id == $usuario->id): ?>
                                    
                                <?php else: ?>
                                <td class="pt-3 text-size"><?php echo e($usuario->name); ?>   </td>
                                <td class="pt-3 text-size text-justify">Usuario con Accesos a 
                                     <?php $__currentLoopData = $usuario->roles->pluck('token'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </td>
                                <td class="pt-3 text-size text-center"><?php echo e($usuario->email); ?>   </td>
                                <td class="pt-3 text-size text-center "><?php echo e($usuario->telefono); ?>   </td>
                                <td class="pt-3 text-size">
                                    <a class="btn btn-outline-warning ml-2 mr-2 edit-item" href="<?php echo e(route('usuarios.edit',$usuario->id)); ?>"><i class="fa fa-pen"></i></a>
                                    <button class="btn btn-outline-danger target-modal ml-2 mr-2" data-toggle="modal" data-target="#deleteModalUsuario" data-nombre="<?php echo e($usuario->name); ?>" data-id="<?php echo e($usuario->id); ?>"><i class="fa fa-trash"></i></button>
                                </td>
                                <?php endif; ?>
                                   
                                    
                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                            </tbody>
                        </table>
                        <?php echo e($usuarios->appends(
                            [
                                'orden'=> request('created_at'),
                                'busqueda'=> request('busqueda')
                            ]
                            )->links()); ?>

                    </div>
            </div>
            <hr>
            <div class="mt-5">
                <h3>Registro de Auditorías</h3>
                <form action="<?php echo e(route('usuarios.index')); ?>" class="form-inline float-right mt-2 mb-2">
                    <select name="created_at" class="form-control mr-3">
                            <option value="DESC">Descenente</option>
                            <option  <?php echo e(request('created_at') == "ASC" ? "selected": ""); ?> value="ASC">Ascendente</option>
                    </select>
                    <select name="auditoria_usuario" class="form-control mr-3">
                        <option value="all">-- Seleccionar Usuario --</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" id=""  <?php echo e(request('auditoria_usuario') == $item->id ? "selected": ""); ?> ><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="submit" class="btn btn-success"><i class="fa fa-search"></i></button>
                </form>

                <div class=" table-responsive ">
                    <table class="table table-hover">
                        <caption>Lista de Auditorías</caption>
                        <thead>
                            <tr class="fondo">
                                <th scope="col" style="width: 280px">Usuario</th>
                                <th scope="col" class="text-justify">Descripcion de Actividad</th>
                            </tr>
                        </thead>
                        <tbody>
            
                        <?php $__currentLoopData = $auditorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auditoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                <td class="pt-3 text-size"><?php echo e($auditoria->user->name); ?>   </td>
                                <td class="pt-3 text-size text-justify"><?php echo e($auditoria->descripcion); ?>   </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                        </tbody>
                    </table>
                    <?php echo e($auditorias->appends(
                        [
                            'created_at'=> request('created_at'),
                            'auditoria_usuario'=> request('auditoria_usuario')
                        ]
                        )->links()); ?>

                </div>
            </div>

        </div>

        <div class="tab-pane fade <?php echo e((session('active-rol')) ? 'active show' : ' '); ?>" id="p-roles" role="tabpanel" aria-labelledby="home-tab">
            <div class="mt-3">
                <button type="button" data-toggle="modal" data-target="#agregarModalRol" class="btn btn-success mt-2 mb-2">Agregar <i class="fa fa-plus"></i> </button>
                    <div class=" table-responsive ">
                        <table class="table table-hover">
                            <caption>Lista de Roles Registrados</caption>
                            <thead>
                                <tr class="fondo">
                                    <th scope="col" style="width: 250px">Módulo</th>
                                    <th scope="col">Descripcion del Rol</th>
                                    <th scope="col" style="width: 100px"><div class="text-center tabla-w"><span>Acciones</span></div></th>
                                </tr>
                            </thead>
                            <tbody>
                
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                    <td class="pt-3 text-size"><?php echo e($role->token); ?>   </td>
                                    <td class="pt-3 text-size text-justify"><?php echo e($role->nombre); ?>   </td>
                                    <td class="pt-3 text-size ">
                                        <button class="btn btn-outline-warning ml-2 mr-2 edit-item" data-toggle="modal" data-target="#updateModalRol" data-descripcion="<?php echo e($role->nombre); ?>" data-id="<?php echo e($role->id); ?>" data-nombre="<?php echo e($role->token); ?>"><i class="fa fa-pen"></i></button>
                                        <button class="btn btn-outline-danger target-modal ml-2 mr-2" data-toggle="modal" data-target="#deleteModalRol" data-nombre="<?php echo e($role->token); ?>" data-id="<?php echo e($role->id); ?>"><i class="fa fa-trash"></i></button>
                                    </td>                          
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>

    </div>
    
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('modals'); ?>

<div class="modal fade mt-5"  id="deleteModalUsuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5 "  role="document">
        <div class="modal-content  mt-5" >
            <div class="modal-header" >
                <h5 class="modal-title " id="modalLabel"><i class="fa fa-exclamation-triangle text-danger mr-2"></i> Advertencia</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body  mt-3">
                <p class="w-100 text-justify">Esta acción borrará el Usuario seleccionado, de forma permanente.
                <br>
                <small><strong></strong></small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                <form id="formDeleteUsuario" method="POST" action="<?php echo e(route('usuarios.destroy',0)); ?>"
                    data-action="<?php echo e(route('usuarios.destroy',0)); ?>">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Borrar</button>
                </form>


            </div>
        </div>
    </div>
</div>


<div class="modal fade mt-5" id="agregarModalRol" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5" role="document">
        <div class="modal-content mt-5">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel"><i class="fa fa-pencil-alt text-success mr-2"></i> Agregar Nuevo Rol</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formAgregarRol" method="POST" action="<?php echo e(route('role.post')); ?>">
                    <?php echo csrf_field(); ?>  
                    <div class="form-group">
                        <input class="form-control" type="text" name="nombre"  value="<?php echo e(old('nombre')); ?>" placeholder="Nombre del Nuevo Rol">
                        <label for="desc-rol" class="mt-3">Agrega la Descripción del Nuevo Rol</label>
                        <textarea class="form-control mt-1" name="descripcion" id="desc-rol"></textarea>
                    </div>

                    <input type="submit" id="btn-rol">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                <button type="button" id="rol-enviar" class="btn btn-success" >Agregar</button>
            </div>
        </div>
    </div>
</div>



<div class="modal fade mt-5" id="updateModalRol" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5" role="document">
        <div class="modal-content mt-5">
            <div class="modal-header">
                <h5 class="modal-title " id="modalLabel"><i class="fa fa-pencil-alt text-warning mr-2"></i> Actualizar Rol</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formUpdateRol" method="POST" action="<?php echo e(route('role.update',0)); ?>"
                    data-action="<?php echo e(route('role.update',0)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input class="form-control" type="text" name="nombre"  value="" placeholder="Nombre del Rol">
                        <label for="desc-rol" class="mt-3">Actualizar Descripción del Rol</label>
                        <textarea class="form-control mt-1" name="descripcion" id="desc-rol"></textarea>
                    </div>

                    <input type="submit" id="btn-update-rol">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                <button type="button" id="up-rol" class="btn btn-warning" >Actualizar</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade mt-5"  id="deleteModalRol" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5 "  role="document">
        <div class="modal-content  mt-5" >
            <div class="modal-header" >
                <h5 class="modal-title " id="modalLabel"><i class="fa fa-exclamation-triangle text-danger mr-2"></i> Advertencia</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body  mt-3">
                <p class="w-100 text-justify">Esta acción borrará el registro y todos los archivos relacionados con el mismo, de forma permanente
                <br>
                <small><strong></strong></small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                <form id="formDeleteRol" method="POST" action="<?php echo e(route('role.delete',0)); ?>"
                    data-action="<?php echo e(route('role.delete',0)); ?>">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Borrar</button>
                </form>


            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>







<?php $__env->startSection('scripts'); ?>

<script>
window.onload = function (){
        $('#btn-rol').hide();

        $('#rol-enviar').click(function() {
            $('#btn-rol').click();
        });
        

        $('#btn-update-rol').hide();

        $('#up-rol').click(function() {
            $('#btn-update-rol').click();
        });


        $('#updateModalRol').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var descripcion= button.data('descripcion')
        var nombre = button.data('nombre')  
        var id = button.data('id') 
        action = $('#formUpdateRol').attr('data-action').slice(0,-1);
        action += id
        $('#formUpdateRol').attr('action',action);

        var modal = $(this);
        modal.find('.modal-body > form > div > input[type="text"]').val(nombre);
        modal.find('.modal-body > form > div > textarea').val(descripcion);
        });


        $('#deleteModalRol').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var nombre = button.data('nombre') 
        var id = button.data('id') 
        action = $('#formDeleteRol').attr('data-action').slice(0,-1);
        action += id
        $('#formDeleteRol').attr('action',action);

        var modal = $(this);
        modal.find('.modal-body >p> small >strong').text("( "+nombre+" )");
        });

        
        $('#deleteModalUsuario').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var nombre = button.data('nombre') 
        var id = button.data('id') 
        action = $('#formDeleteUsuario').attr('data-action').slice(0,-1);
        action += id
        $('#formDeleteUsuario').attr('action',action);

        var modal = $(this);
        modal.find('.modal-body >p> small >strong').text("( "+nombre+" )");
        });

}
</script>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/user/index.blade.php ENDPATH**/ ?>