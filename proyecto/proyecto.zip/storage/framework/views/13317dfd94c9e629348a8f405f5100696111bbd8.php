

<?php $__env->startSection('link_t','active'); ?>
<?php $__env->startSection('link_t_a','activo-l'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 mb-5">
        <h3 class="my-4">Plataformas de Transparencia</h3>
        <hr>
    </div>
    <div class="col-md-6  col-sm-12 pt-2">
        <a href="https://transparenciachihuahua.org/infomex/" target="_blank" class="text-center d-block mt-5"><img src="<?php echo e(asset("web/img/transparencia/log-01.png")); ?>"  height="170px" alt=""></a>
    </div>
    <div class="col-md-6 col-sm-12 pt-2">
        <a href="https://www.plataformadetransparencia.org.mx/web/guest/inicio" target="_blank" class="text-center d-block mt-5"><img src="<?php echo e(asset("web/img/transparencia/log-02.png")); ?>"  height="170px" alt=""></a>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.main-sec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/transparencia/index.blade.php ENDPATH**/ ?>