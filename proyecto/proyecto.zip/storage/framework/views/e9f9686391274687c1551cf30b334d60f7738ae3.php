
<?php $__env->startSection('link_m', 'btn-info'); ?>


<?php $__env->startSection('contenedor'); ?>
   <div class="col-12">
    <hr>
   </div>
   <div class="col-12 mt-2 mb-3">
    <form action="<?php echo e(route('mensual.index')); ?>" class="form-inline">
        <div class="input-group col-12">
          <input type="text" name="busqueda" class="form-control " value="<?php echo e(request('busqueda')); ?>" placeholder="Buscar...">
          <span class="input-group-append">
          <button class="btn btn-secondary" type="submit"><i class="fa fa-search"></i></button>
          </span>
        </div>
      </form>
   </div>
   <?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 mb-2">
           <a href="<?php echo e(route('reporte.dowload', $reporte->archivo)); ?>" class="d-block btn btn-info pt-3 pb-3 text-left"><?php echo e($reporte->titulo); ?> <i class="fa fa-download float-right mt-1"></i></a>
       </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <div class="col-12 mt-4">
    <?php echo e($reportes->appends( ['busqueda'=> request('busqueda')])->links()); ?>

   </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.tesoreria.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/tesoreria/mensual.blade.php ENDPATH**/ ?>