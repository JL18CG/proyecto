
<?php $__env->startSection('link_n_mu','activo-l'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">  
    <div class="col-12">
      <h3 class="my-4 text-center">Lugares Interesantes Para Visitar</h3>
      <hr class="divider-sm">
    </div>


  <div class="col-12 p-5">  
    <?php $__currentLoopData = $sitios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sitio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

        <div class="row card mb-5">
            <div class="col mt-2 mb-2 d-sm-flex  flex-xs-column flex-sm-column align-items-center flex-sm-row flex-lg-row ">
              <div class="<?php echo e(($key%2==0) ? 'order-lg-1 ' : 'order-lg-2 '); ?> col-xs-12 col-sm-12 col-md-12 col-lg-6">
            
                  <img class="w-100 " src="<?php echo e(asset("web/img/sitios/thumbs/".$sitio->img)); ?>" alt="">
         
              </div>
              
              <div class="<?php echo e(($key%2==0) ? 'order-lg-2' : 'order-lg-1'); ?> col-xs-12 col-sm-12 col-md-12 col-lg-6">
                  <div class="card-body">
                      <p class="text-center font-weight-bold"><?php echo e($sitio->nombre_lugar); ?></p>
                      <p class="card-text text-center"><?php echo e($sitio->descripcion); ?></p>
                      <hr>
                      <small class="d-block text-center"><?php echo e($sitio->tipo_lugar); ?></small>
                  </div>
                  <div class="text-center">
                      <p><a href="<?php echo e($sitio->ubicacion); ?>" target="_blank" class="btn btn-light "><?php echo e($sitio->direccion); ?> <i class="fas fa-map-marker-alt ml-2"></i></a> </p>
                      
                  </div>
              </div>
            </div>
        </div>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php echo e($sitios->links()); ?>



</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('pagina.main-sec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/pagina/turismo/index.blade.php ENDPATH**/ ?>