
<?php $__env->startSection('titulo'); ?> Turismo <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="pt-1 pb-5">
    <h3 class="h2 d-block pt-2">Panel de Turismo</h3>
    <hr>    
    <p>Agrega Proximos Eventos o Los Lugares Atractivos Para Visitar</p>

    <ul class="nav nav-tabs mt-4" id="myTab" role="tablist">
        <li class="nav-item ">
        <a class="nav-link <?php echo e((session('active')) ? '' : 'active'); ?>" id="home-tab" data-toggle="tab" href="#p-noticia" role="tab" aria-controls="p-noticia" aria-selected="true">Registro de Eventos</a>
        </li>
        <li class="nav-item ">
        <a class="nav-link <?php echo e((session('active')) ? 'active' : ''); ?>" id="profile-tab" data-toggle="tab" href="#p-lugares" role="tab" aria-controls="p-lugares" aria-selected="false">Registro de Lugares</a>
        </li>
    </ul>

    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade <?php echo e((session('active')) ? '' : 'active show '); ?> " id="p-noticia" role="tabpanel" aria-labelledby="home-tab">

            <div class="mt-3">
                <a href="<?php echo e(route('eventos.create')); ?>" type="button" class="btn btn-success mt-2 mb-2">Agregar <i class="fa fa-plus"></i> </a>
                
                <div class=" table-responsive ">
                    <table class="table table-hover">
                        <caption>Listas de Eventos y Sitios Publicados</caption>
                        <thead>
                        <tr class="fondo">
                            <th scope="col " style="min-width:550px !important;">Título del Evento</th>
                            <th scope="col " class="text-center">Fecha y Hora</th>
                            <th scope="col " class="text-center">Publicado</th>
                            <th scope="col "><div class="text-center tabla-w"><span>Acciones</span></div></th>
                        </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                    <td class="pt-3 text-size"><?php echo e($evento->titulo); ?>   </td>
                                    <td class="pt-3 text-size text-center"><?php echo e($evento->created_at); ?>  </td>
                                    <td class="pt-3 text-size text-center "><?php echo e($evento->fecha); ?>   </td>
                                    <td class="pt-3 text-size">
                                        <a class="btn btn-outline-warning ml-2 mr-2 edit-item" href="<?php echo e(route('eventos.edit',$evento->id)); ?>"><i class="fa fa-pen"></i></a>
                                        <button class="btn btn-outline-danger target-modal ml-2 mr-2" data-toggle="modal" data-target="#deleteEvento" data-nombre="<?php echo e($evento->titulo); ?>" data-id="<?php echo e($evento->id); ?>"><i class="fa fa-trash"></i></button>
                                    </td>
                                    
                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       

            
                        </tbody>
                    </table>
                </div>
            </div>
            

        </div>

        <div class="tab-pane fade <?php echo e((session('active')) ? 'active show ' : ''); ?> " id="p-lugares" role="tabpanel" aria-labelledby="profile-tab">

            <div class="mt-3">
                <a href="<?php echo e(route('sitios.create')); ?>" type="button" class="btn btn-success mt-2 mb-2">Agregar <i class="fa fa-plus"></i> </a>
                <div class="col-12 m-table">
                    <div class="table-responsive">
                        <table class="table table-hover ">
                            <caption>Lista de Categorías Registradas</caption>
                            <thead>
                            <tr class="fondo">
                                <th scope="col style="min-width:550px !important;"">Nombre del Lugar</th>
                                <th scope="col">Tipo del lugar</th>
                                <th scope="col"><div class="text-center tabla-w"><span>Acciones</span></div></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sitios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sitio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <td class="pt-3 text-size"><?php echo e($sitio->nombre_lugar); ?>   </td>
                                        <td class="pt-3 text-size text-center "><?php echo e($sitio->tipo_lugar); ?>   </td>
                                        <td class="pt-3 text-size">
                                            <a class="btn btn-outline-warning ml-2 mr-2 edit-item" href="<?php echo e(route('sitios.edit',$sitio->id)); ?>"><i class="fa fa-pen"></i></a>
                                            <button class="btn btn-outline-danger target-modal ml-2 mr-2" data-toggle="modal" data-target="#deleteModalLugar" data-nombre="<?php echo e($sitio->nombre_lugar); ?>" data-id="<?php echo e($sitio->id); ?>"><i class="fa fa-trash"></i></button>
                                        </td>
                                        
                                
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
            
            
            

        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('modals'); ?>
<div class="modal fade mt-5"  id="deleteModalLugar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5 "  role="document">
        <div class="modal-content  mt-5" >
            <div class="modal-header" >
                <h5 class="modal-title " id="modalLabel"><i class="fa fa-exclamation-triangle text-danger mr-2"></i> Advertencia</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body  mt-3">
                <p class="w-100 text-justify">Esta acción borrará el registro y todos los archivos relacionados con el mismo, de forma permanente
                <br>
                <small><strong></strong></small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                <form id="formDelete" method="POST" action="<?php echo e(route('sitios.destroy',0)); ?>"
                    data-action="<?php echo e(route('sitios.destroy',0)); ?>">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Borrar</button>
                </form>


            </div>
        </div>
    </div>
</div>
<div class="modal fade mt-5"  id="deleteEvento" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mt-5 "  role="document">
        <div class="modal-content  mt-5" >
            <div class="modal-header" >
                <h5 class="modal-title " id="modalLabel"><i class="fa fa-exclamation-triangle text-danger mr-2"></i> Advertencia</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body  mt-3">
                <p class="w-100 text-justify">Esta acción borrará el registro y todos los archivos relacionados con el mismo, de forma permanente
                <br>
                <small><strong></strong></small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                <form id="formDelete-evt" method="POST" action="<?php echo e(route('eventos.destroy',0)); ?>"
                    data-action="<?php echo e(route('eventos.destroy',0)); ?>">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger">Borrar</button>
                </form>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

<script>
window.onload = function (){

        $('#deleteEvento').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var nombre = button.data('nombre') 
        var id = button.data('id') 
        action = $('#formDelete-evt').attr('data-action').slice(0,-1);
        action += id
        console.log(action)
        $('#formDelete-evt').attr('action',action);

        var modal = $(this);
        modal.find('.modal-body >p> small >strong').text("( "+nombre+" )");
        });
        
    
    $('#deleteModalLugar').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var nombre = button.data('nombre') 
        var id = button.data('id') 
        action = $('#formDelete').attr('data-action').slice(0,-1);
        action += id
        console.log(action)
        $('#formDelete').attr('action',action);

        var modal = $(this);
        modal.find('.modal-body >p> small >strong').text("( "+nombre+" )");
        });
    }
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/turismo/index.blade.php ENDPATH**/ ?>