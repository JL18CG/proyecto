<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset("img/iconos/icon.png")); ?>">
    <title>Iniciar Seción</title>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilos-main-login.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("css/anim-page.css")); ?>">

</head>
<body>

    <div class="alert-preloader" id="preloader-page">
        <div class="d-flex justify-content-center cargar">
            <div class="loader loader-g">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>
            </div>
            </div>
        </div>
    </div>
    <?php echo $__env->yieldContent('content'); ?>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
          setTimeout(function(){ 

            $( "#preloader-page" ).fadeOut( "slow");
            }, 1000);
    </script>
</body>
</html>
<?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/layouts/app.blade.php ENDPATH**/ ?>