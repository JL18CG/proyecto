
<?php $__env->startSection('titulo'); ?> Inicio <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mt-3">
        <h3 class="h2 text-center">Municipio de Casas Grandes</h3>
    </div>
  
</div>
<hr>
<div class="d-flex justify-content-center mt-5">

        <img class="mx-auto mt-5" src="<?php echo e(asset("img/publics/d-ipp/d-imp-log/logo-pueblo-magico.png")); ?>" height="250px" alt="">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/home/index.blade.php ENDPATH**/ ?>