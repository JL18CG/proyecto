<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('panel.index')); ?>"><img src="<?php echo e(asset("img/logos/nav.png")); ?>" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->user()->admin=="si"): ?>
                    <?php echo $__env->make('panel.partials.nav_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <?php if(auth()->user()->admin=="no"): ?>
                    <?php echo $__env->make('panel.partials.nav_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Jose\Desktop\pagina\proyecto\proyecto\resources\views/panel/partials/nav.blade.php ENDPATH**/ ?>