$("#mainNav").addClass("navbar-scrolled");
setTimeout(function(){ 

    $( "#preloader-page" ).fadeOut( "slow");
}, 1200);
$("#div2").fadeOut("slow");