<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reporte extends Model
{
    protected $fillable = [
        'tipo','titulo','archivo','clas_reporte'
    ];
}
