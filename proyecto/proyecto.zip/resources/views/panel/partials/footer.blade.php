
    <footer class="footer navbar-light bg-light shadow-sm">
        <div class="container pt-5 pb-2">
            <div class="text-center">
                   <a class=" " href="#!"><img src="{{ asset("img/logos/nav-001.png") }}" alt=""></a>
                   <p class="mt-5">Gobierno Municipal de Casas Grandes 2020&copy; Todos los Derechos Reservados</p> 
            </div>
        </div>
    </footer>
