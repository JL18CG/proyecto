@extends('panel.main')
@section('titulo') Inicio @endsection
@section('content')
<div class="row">
    <div class="col-12 mt-3">
        <h3 class="h2 text-center">Municipio de Casas Grandes</h3>
    </div>
  
</div>
<hr>
<div class="d-flex justify-content-center mt-5">

        <img class="mx-auto mt-5" src="{{ asset("img/publics/d-ipp/d-imp-log/logo-pueblo-magico.png") }}" height="250px" alt="">

</div>
@endsection
